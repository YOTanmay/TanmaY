
import React from 'react';
import { AppState, User } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  showBack?: boolean;
  onBack?: () => void;
  activeState: AppState;
  onNavigate: (state: AppState) => void;
  user: User | null;
  onLogout: () => void;
  onUpdateUser: (updates: Partial<User>) => void;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  isDarkMode, 
  onToggleTheme, 
  showBack, 
  onBack,
  activeState,
  onNavigate,
  user,
  onLogout,
  onUpdateUser
}) => {
  const isHomeActive = [AppState.IDLE, AppState.PROCESSING, AppState.QUIZ, AppState.TOPIC_EXPANSION].includes(activeState);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300 pb-20 md:pb-0">
      <header className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {showBack && (
              <button 
                onClick={onBack}
                className="p-2 -ml-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                aria-label="Go back"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
              </button>
            )}
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate(AppState.IDLE)}>
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
                AQ
              </div>
              <h1 className="text-lg md:text-xl font-black bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600 dark:from-indigo-400 dark:to-violet-400">
                AI Quiz
              </h1>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-6">
            <nav className="hidden md:flex gap-6 text-sm font-bold">
              <button 
                onClick={() => onNavigate(AppState.IDLE)}
                className={`transition-colors ${isHomeActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:text-indigo-600'}`}
              >
                Home
              </button>
              <button 
                onClick={() => onNavigate(AppState.HISTORY)}
                className={`transition-colors ${activeState === AppState.HISTORY ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:text-indigo-600'}`}
              >
                History
              </button>
            </nav>

            <button
              onClick={onToggleTheme}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 transition-all focus:outline-none"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 9h-1m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>
              )}
            </button>

            {user ? (
              <div 
                className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-700 cursor-pointer group"
                onClick={() => onNavigate(AppState.PROFILE)}
              >
                <div className="hidden lg:block text-right">
                  <p className="text-xs font-black text-slate-800 dark:text-slate-100 truncate max-w-[100px] group-hover:text-indigo-600 transition-colors">YOU</p>
                  <p className="text-[10px] font-bold text-slate-400">{user.name}</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center text-white font-black text-xs shadow-lg shadow-indigo-200 dark:shadow-none overflow-hidden border-2 border-transparent group-hover:border-indigo-500 transition-all">
                  {user.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    user.name.charAt(0).toUpperCase()
                  )}
                </div>
              </div>
            ) : (
              <button 
                onClick={() => onNavigate(AppState.AUTH)}
                className="hidden md:block px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 h-16 flex items-center justify-around px-4 z-50 shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <button 
          onClick={() => onNavigate(AppState.IDLE)}
          className={`flex flex-col items-center gap-1 transition-colors ${isHomeActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
          <span className="text-[10px] font-bold uppercase">Home</span>
        </button>
        <button 
          onClick={() => onNavigate(AppState.HISTORY)}
          className={`flex flex-col items-center gap-1 transition-colors ${activeState === AppState.HISTORY ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="text-[10px] font-bold uppercase">History</span>
        </button>
        <button 
          onClick={() => user ? onNavigate(AppState.PROFILE) : onNavigate(AppState.AUTH)}
          className={`flex flex-col items-center gap-1 transition-colors ${activeState === AppState.PROFILE || activeState === AppState.AUTH ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}
        >
          {user ? (
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black border transition-all overflow-hidden ${
              activeState === AppState.PROFILE 
                ? 'bg-indigo-600 text-white border-indigo-600 scale-110' 
                : 'bg-indigo-100 text-indigo-600 border-indigo-200'
            }`}>
               {user.avatar ? (
                 <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
               ) : (
                 user.name.charAt(0).toUpperCase()
               )}
            </div>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          )}
          <span className="text-[10px] font-bold uppercase">YOU</span>
        </button>
      </nav>

      <main className="max-w-5xl mx-auto px-4 py-6 md:py-8">
        {children}
      </main>

      <footer className="hidden md:block py-8 text-center text-slate-400 dark:text-slate-500 text-sm border-t border-slate-100 dark:border-slate-800 mt-12">
        &copy; {new Date().getFullYear()} AI Quiz. Powered by Gemini.
      </footer>
    </div>
  );
};
