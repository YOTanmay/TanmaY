
import React from 'react';
import { QuizHistoryItem } from '../types';

interface HistoryViewProps {
  history: QuizHistoryItem[];
  onSelectItem: (item: QuizHistoryItem) => void;
  onDeleteItem: (id: string) => void;
  onGoHome: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ history, onSelectItem, onDeleteItem, onGoHome }) => {
  if (history.length === 0) {
    return (
      <div className="text-center py-16 px-6 bg-white dark:bg-slate-800 rounded-[2.5rem] border border-slate-100 dark:border-slate-700 shadow-xl shadow-slate-200/50 dark:shadow-none transition-all">
        <div className="w-20 h-20 bg-indigo-50 dark:bg-indigo-900/30 rounded-3xl flex items-center justify-center mx-auto mb-6 text-indigo-500">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h3 className="text-xl font-black text-slate-800 dark:text-slate-100 mb-2">Clean Slate!</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-8 max-w-xs mx-auto">
          You haven't taken any quizzes yet. Your results and study progress will appear here.
        </p>
        <button
          onClick={onGoHome}
          className="w-full sm:w-auto bg-indigo-600 text-white font-black py-4 px-10 rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 dark:shadow-indigo-900/20 uppercase tracking-widest text-xs"
        >
          Go Home
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between px-2">
        <h2 className="text-2xl font-black text-slate-800 dark:text-slate-100">Your Journey</h2>
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{history.length} Sessions</span>
      </div>

      <div className="grid gap-3">
        {history.map((item) => {
          const dateStr = new Date(item.date).toLocaleDateString(undefined, {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          });

          return (
            <div 
              key={item.id}
              className="bg-white dark:bg-slate-800 rounded-[1.5rem] p-4 border border-slate-100 dark:border-slate-700 shadow-sm hover:shadow-lg transition-all active:scale-[0.98] flex items-center gap-4 cursor-pointer"
              onClick={() => onSelectItem(item)}
            >
              <div className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center font-black flex-shrink-0 ${
                item.score >= 80 ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400' :
                item.score >= 60 ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' :
                'bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400'
              }`}>
                <span className="text-lg">{item.score}</span>
                <span className="text-[8px] -mt-1 uppercase">%</span>
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm truncate leading-tight mb-0.5">
                  {item.title || "Untitled Session"}
                </h4>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-black uppercase tracking-wider">
                  <span>{dateStr}</span>
                  <span className="w-1 h-1 bg-slate-300 rounded-full" />
                  <span>{item.questions.length} Qs</span>
                </div>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (window.confirm('Are you sure you want to delete this session?')) {
                    onDeleteItem(item.id);
                  }
                }}
                className="p-3 text-slate-200 hover:text-rose-500 transition-colors"
                aria-label="Delete history entry"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
