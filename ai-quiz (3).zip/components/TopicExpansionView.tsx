
import React, { useState, useEffect } from 'react';
import { ExpandedTopic } from '../types';
import { fetchLinkMetadata } from '../services/geminiService';
import { jsPDF } from 'jspdf';

interface TopicExpansionViewProps {
  data: ExpandedTopic;
  onGenerateQuiz: () => void;
  onBack: () => void;
  onGenerateSectionVisual: (index: number, text: string) => Promise<void>;
}

const LinkPreview: React.FC<{ url: string }> = ({ url }) => {
  const [metadata, setMetadata] = useState<{ title: string; description: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function getMeta() {
      const data = await fetchLinkMetadata(url);
      if (isMounted) {
        setMetadata(data);
        setLoading(false);
      }
    }
    getMeta();
    return () => { isMounted = false; };
  }, [url]);

  const domain = new URL(url).hostname;
  const favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=128`;

  if (loading) {
    return (
      <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700 animate-pulse flex items-center gap-3">
        <div className="w-10 h-10 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
        <div className="flex-1 space-y-2">
          <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded w-1/2"></div>
          <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded w-full"></div>
        </div>
      </div>
    );
  }

  return (
    <a 
      href={url} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="group block p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-600 hover:shadow-md transition-all"
    >
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-50 dark:bg-slate-800 flex-shrink-0 border border-slate-100 dark:border-slate-700 flex items-center justify-center">
          <img src={favicon} alt="" className="w-6 h-6 grayscale group-hover:grayscale-0 transition-all" />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
            {metadata?.title || url}
          </h4>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1">
            {metadata?.description || domain}
          </p>
        </div>
        <div className="text-slate-300 group-hover:text-indigo-500 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" />
            <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" />
          </svg>
        </div>
      </div>
    </a>
  );
};

export const TopicExpansionView: React.FC<TopicExpansionViewProps> = ({ data, onGenerateQuiz, onBack, onGenerateSectionVisual }) => {
  const [loadingSections, setLoadingSections] = useState<Record<number, boolean>>({});
  const [copied, setCopied] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const handleCopyTitle = async () => {
    try {
      await navigator.clipboard.writeText(data.title);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const handleDownloadPDF = async () => {
    setIsGeneratingPdf(true);
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 20;
      const contentWidth = pageWidth - (margin * 2);
      let y = 20;

      // Title
      doc.setFontSize(22);
      doc.setFont('helvetica', 'bold');
      const titleLines = doc.splitTextToSize(data.title, contentWidth);
      doc.text(titleLines, margin, y);
      y += (titleLines.length * 10) + 5;

      // Summary
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Summary', margin, y);
      y += 7;
      doc.setFontSize(11);
      doc.setFont('helvetica', 'italic');
      const summaryLines = doc.splitTextToSize(data.summary, contentWidth);
      doc.text(summaryLines, margin, y);
      y += (summaryLines.length * 6) + 10;

      // Key Concepts
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Key Terminology', margin, y);
      y += 7;
      doc.setFontSize(11);
      data.keyConcepts.forEach(concept => {
        if (y > 270) { doc.addPage(); y = 20; }
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${concept.term}:`, margin, y);
        y += 5;
        doc.setFont('helvetica', 'normal');
        const defLines = doc.splitTextToSize(concept.definition, contentWidth - 5);
        doc.text(defLines, margin + 5, y);
        y += (defLines.length * 6) + 4;
      });
      y += 6;

      // Detailed Explanation
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Detailed Deep Dive', margin, y);
      y += 8;
      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      const paragraphs = data.detailedExplanation.split('\n').filter(p => p.trim() !== '');
      paragraphs.forEach(para => {
        const paraLines = doc.splitTextToSize(para, contentWidth);
        if (y + (paraLines.length * 6) > 280) {
          doc.addPage();
          y = 20;
        }
        doc.text(paraLines, margin, y);
        y += (paraLines.length * 6) + 6;
      });

      // Related Topics
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Related Topics', margin, y);
      y += 7;
      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      data.relatedTopics.forEach(topic => {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(`- ${topic}`, margin, y);
        y += 6;
      });

      doc.save(`${data.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_study_guide.pdf`);
    } catch (err) {
      console.error('PDF Generation Error:', err);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleGenerateVisual = async (index: number, text: string) => {
    setLoadingSections(prev => ({ ...prev, [index]: true }));
    try {
      await onGenerateSectionVisual(index, text);
    } finally {
      setLoadingSections(prev => ({ ...prev, [index]: false }));
    }
  };

  const paragraphs = data.detailedExplanation.split('\n').filter(p => p.trim() !== '');

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header Section */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-100 dark:border-slate-700 shadow-xl transition-colors">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Deep Dive Study Guide</span>
            <div className="flex items-center gap-3 group">
              <h2 className="text-3xl font-black text-slate-800 dark:text-slate-100 leading-tight">{data.title}</h2>
              <button 
                onClick={handleCopyTitle}
                className={`p-2 rounded-lg transition-all ${
                  copied 
                    ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' 
                    : 'bg-slate-50 dark:bg-slate-700/50 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 opacity-0 group-hover:opacity-100'
                }`}
                title="Copy title to clipboard"
              >
                {copied ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 00-2 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                  </svg>
                )}
              </button>
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <button 
              onClick={onBack}
              className="px-6 py-3 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-600"
            >
              Back
            </button>
            <button 
              onClick={handleDownloadPDF}
              disabled={isGeneratingPdf}
              className="px-6 py-3 rounded-xl font-bold bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900/50 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all flex items-center gap-2 shadow-sm disabled:opacity-50"
            >
              {isGeneratingPdf ? (
                <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              )}
              Export PDF
            </button>
            <button 
              onClick={onGenerateQuiz}
              className="px-6 py-3 rounded-xl font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-indigo-900/20 flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M11.3 1.047a1 1 0 01.897.95V4.69l2.713-1.017a1 1 0 011.24.58l.7 1.922a1 1 0 01-.58 1.24L13.56 8.432l2.712 1.017a1 1 0 01.58 1.24l-.7 1.922a1 1 0 01-1.24.58L12.197 13.174l-.001 2.73a1 1 0 01-.95.897H9.25a1 1 0 01-.95-.897l-.001-2.73-2.713 1.017a1 1 0 01-1.24-.58l-.7-1.922a1 1 0 01.58-1.24l2.713-1.017-2.713-1.017a1 1 0 01-.58-1.24l.7-1.922a1 1 0 011.24-.58L7.294 4.69V1.997a1 1 0 01.95-.897h2.056a1.001 1.001 0 01.95.897L11.25 4.69l-.001-2.693a1 1 0 01.051-.95zM10 10.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" clipRule="evenodd" />
              </svg>
              Quiz This Topic
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Main Content (Left Column) */}
        <div className="md:col-span-2 space-y-8">
          
          {/* Visual Aid Hero */}
          <section className="bg-white dark:bg-slate-800 rounded-3xl overflow-hidden border border-slate-100 dark:border-slate-700 shadow-sm">
            <div className="p-6 md:p-8 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-700">
               <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                </svg>
                Overview Illustration
              </h3>
            </div>
            <div className="aspect-video relative bg-slate-100 dark:bg-slate-900 flex items-center justify-center">
              {data.visualAidUrl ? (
                <img 
                  src={data.visualAidUrl} 
                  alt={`Diagram of ${data.title}`} 
                  className="w-full h-full object-contain animate-in fade-in zoom-in-95 duration-700"
                />
              ) : (
                <div className="flex flex-col items-center justify-center text-center p-8">
                  <div className="w-12 h-12 border-4 border-slate-200 dark:border-slate-700 border-t-indigo-500 rounded-full animate-spin mb-4"></div>
                  <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Generating Visual Diagram...</p>
                  <p className="text-[10px] text-slate-400 mt-2 max-w-[200px]">Imagen AI is drawing a relevant educational illustration.</p>
                </div>
              )}
            </div>
          </section>

          <section className="bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-100 dark:border-slate-700 shadow-sm">
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Topic Summary</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed italic border-l-4 border-indigo-500 pl-4 bg-indigo-50/10 dark:bg-indigo-900/5 py-4 rounded-r-xl">
              "{data.summary}"
            </p>
          </section>

          <section className="bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-100 dark:border-slate-700 shadow-sm">
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-6">Detailed Deep Dive</h3>
            <div className="space-y-8">
              {paragraphs.map((para, i) => (
                <div key={i} className="group relative">
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                    {para}
                  </p>
                  
                  {/* Generated Image for this section */}
                  {data.sectionVisuals?.[i] && (
                    <div className="mb-4 rounded-2xl overflow-hidden border border-slate-100 dark:border-slate-700 shadow-lg animate-in fade-in zoom-in-95 duration-500">
                      <img 
                        src={data.sectionVisuals[i]} 
                        alt={`Visual reference for paragraph ${i + 1}`}
                        className="w-full h-auto max-h-[400px] object-cover"
                      />
                    </div>
                  )}

                  <div className="flex justify-end">
                    <button
                      onClick={() => handleGenerateVisual(i, para)}
                      disabled={loadingSections[i] || !!data.sectionVisuals?.[i]}
                      className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        data.sectionVisuals?.[i]
                          ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 cursor-default'
                          : 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 active:scale-95'
                      } ${loadingSections[i] ? 'opacity-70 animate-pulse' : ''}`}
                    >
                      {loadingSections[i] ? (
                        <>
                          <div className="w-3 h-3 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                          Visualizing...
                        </>
                      ) : data.sectionVisuals?.[i] ? (
                        <>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Visual Reference Added
                        </>
                      ) : (
                        <>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                          Visualize this concept
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-100 dark:border-slate-700 shadow-sm">
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-6">Key Terminology</h3>
            <div className="grid gap-4">
              {data.keyConcepts.map((concept, i) => (
                <div key={i} className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all hover:border-indigo-200 dark:hover:border-indigo-900 shadow-sm">
                  <h4 className="font-bold text-indigo-600 dark:text-indigo-400 mb-1">{concept.term}</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{concept.definition}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar (Right Column) */}
        <div className="space-y-8">
          <section className="bg-indigo-50 dark:bg-indigo-900/20 rounded-3xl p-6 border border-indigo-100 dark:border-indigo-900/50 shadow-sm">
            <h3 className="text-lg font-bold text-indigo-900 dark:text-indigo-300 mb-4 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
              </svg>
              Related Topics
            </h3>
            <ul className="space-y-3">
              {data.relatedTopics.map((topic, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-indigo-700 dark:text-indigo-400">
                  <span className="mt-1.5 w-1.5 h-1.5 bg-indigo-400 rounded-full flex-shrink-0"></span>
                  {topic}
                </li>
              ))}
            </ul>
          </section>

          <section className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9 4.804A7.993 7.993 0 0113.144 4c1.455 0 2.842.388 4.038 1.063a.75.75 0 01.318.966l-1.5 3A.75.75 0 0115.314 9.5c-.218 0-.434-.022-.644-.064l-1.127 2.254A5.99 5.99 0 0013.144 11.5c-1.168 0-2.254.333-3.176.908a.75.75 0 01-.936-.024L7.5 10.852l-1.532 1.532a.75.75 0 01-1.06-1.06l2-2a.75.75 0 011.06 0l1.468 1.468a4.493 4.493 0 012.708-.892c.328 0 .646.035.952.102l1.137-2.274a7.994 7.994 0 01-5.227-2.903.75.75 0 01-.006-.941z" />
              </svg>
              Further Learning
            </h3>
            <div className="space-y-4">
              {data.furtherReadingSuggestions.map((item, i) => {
                const urlMatch = item.match(/https?:\/\/[^\s]+/);
                if (urlMatch) {
                  return <LinkPreview key={i} url={urlMatch[0]} />;
                }
                return (
                  <div key={i} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-400">
                    <span className="mt-1.5 w-1.5 h-1.5 bg-slate-300 dark:bg-slate-600 rounded-full flex-shrink-0"></span>
                    {item}
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
