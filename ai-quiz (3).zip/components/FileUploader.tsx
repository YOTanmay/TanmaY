
import React, { useState, useRef, useEffect } from 'react';
import { Difficulty, TimeLimit } from '../types';

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB in bytes

interface FileUploaderProps {
  onProcess: (content: { 
    text?: string; 
    files?: { data: string; mimeType: string }[]; 
    difficulty: Difficulty; 
    mode: 'quiz' | 'expand';
    questionCount: number;
    timeLimit: TimeLimit;
  }) => void;
  isLoading: boolean;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onProcess, isLoading }) => {
  const [textInput, setTextInput] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<{ id: string; data: string; mimeType: string; preview: string; name: string }[]>([]);
  const [difficulty, setDifficulty] = useState<Difficulty>('Medium');
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [timeLimit, setTimeLimit] = useState<TimeLimit>(60);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const handleFiles = (files: FileList) => {
    Array.from(files).forEach(file => {
      if (file.size > MAX_FILE_SIZE) {
        alert(`File "${file.name}" is too large. Maximum size is 50MB.`);
        return;
      }

      if (file.type.startsWith('image/') || file.type === 'application/pdf') {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          setSelectedFiles(prev => [...prev, {
            id: Math.random().toString(36).substr(2, 9),
            data: result.split(',')[1],
            mimeType: file.type,
            preview: file.type === 'application/pdf' ? '' : result,
            name: file.name
          }]);
        };
        reader.readAsDataURL(file);
        setTextInput('');
      } else {
        alert("Supported formats: Images (PNG, JPG) and PDFs.");
      }
    });
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files);
    }
  };

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraActive(true);
      setTextInput('');
    } catch (err) {
      setCameraError("Unable to access camera. Please check permissions.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setSelectedFiles(prev => [...prev, {
          id: Math.random().toString(36).substr(2, 9),
          data: dataUrl.split(',')[1],
          mimeType: 'image/jpeg',
          preview: dataUrl,
          name: `Snap-${new Date().getTime()}.jpg`
        }]);
      }
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const removeFile = (id: string) => {
    setSelectedFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(e.type === "dragenter" || e.type === "dragover");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleSubmit = async (mode: 'quiz' | 'expand') => {
    if (selectedFiles.length > 0) {
      onProcess({ 
        files: selectedFiles.map(f => ({ data: f.data, mimeType: f.mimeType })), 
        difficulty, 
        mode,
        questionCount,
        timeLimit
      });
    } else if (textInput.trim()) {
      onProcess({ text: textInput, difficulty, mode, questionCount, timeLimit });
    }
  };

  const canSubmit = (selectedFiles.length > 0 || textInput.trim()) && !isLoading;

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="text-center space-y-2">
        <h2 className="text-2xl md:text-3xl font-black text-slate-800 dark:text-slate-100">AI Quiz</h2>
        <p className="text-sm md:text-base font-bold text-indigo-600 dark:text-indigo-400 max-w-sm mx-auto uppercase tracking-wider">Your ultimate AI learning partner</p>
        <p className="text-xs text-slate-500 dark:text-slate-500 max-w-xs mx-auto">Upload documents, snap photos, or paste text to generate interactive tests.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <div 
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`relative group border-2 border-dashed rounded-3xl p-5 md:p-6 flex flex-col transition-all min-h-[340px] ${
            dragActive 
              ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' 
              : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500 shadow-sm'
          }`}
        >
          {isCameraActive ? (
            <div className="w-full h-full flex flex-col items-center">
              <div className="relative w-full flex-1 mb-4 overflow-hidden rounded-2xl bg-black border border-slate-200 dark:border-slate-700">
                 <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/40 backdrop-blur-md px-2 py-1 rounded-lg">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-[10px] text-white font-bold uppercase tracking-wider">Live View</span>
                </div>
              </div>
              <canvas ref={canvasRef} className="hidden" />
              <div className="flex gap-3 w-full">
                <button 
                  onClick={capturePhoto}
                  className="flex-1 bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 dark:shadow-indigo-900/20"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4 5a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.121-1.121A2 2 0 0011.172 3H8.828a2 2 0 00-1.414.586L6.293 4.707A1 1 0 015.586 5H4zm6 9a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                  </svg>
                  Snap Page
                </button>
                <button 
                  onClick={stopCamera}
                  className="p-4 bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 rounded-2xl hover:bg-slate-200 dark:hover:bg-slate-600 transition-all"
                  aria-label="Close camera"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center flex-1 py-4">
              <div className="w-14 h-14 bg-slate-50 dark:bg-slate-900/50 rounded-2xl flex items-center justify-center text-slate-300 dark:text-slate-600 mb-4 transition-colors group-hover:text-indigo-500 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/40">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <p className="text-sm font-bold text-slate-600 dark:text-slate-300 mb-6">Scan or Upload Material</p>
              
              <div className="grid grid-cols-2 gap-3 w-full">
                <button 
                  onClick={startCamera}
                  className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 p-4 rounded-2xl font-bold text-sm hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-all flex flex-col items-center gap-2 border border-indigo-100 dark:border-indigo-900/50"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  Camera
                </button>
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-slate-50 dark:bg-slate-700/30 text-slate-600 dark:text-slate-300 p-4 rounded-2xl font-bold text-sm hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-all flex flex-col items-center gap-2 border border-slate-100 dark:border-slate-700"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Files
                </button>
              </div>
            </div>
          )}

          {selectedFiles.length > 0 && (
            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700 w-full animate-in fade-in duration-300">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{selectedFiles.length} Pages</span>
                <button onClick={() => setSelectedFiles([])} className="text-[10px] font-black text-rose-500 uppercase tracking-widest hover:underline">Clear All</button>
              </div>
              <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                {selectedFiles.map((file) => (
                  <div key={file.id} className="relative flex-shrink-0 w-16 aspect-[3/4] bg-slate-100 dark:bg-slate-900 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                    {file.mimeType === 'application/pdf' ? (
                      <div className="flex flex-col items-center justify-center p-1 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-rose-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                        <span className="text-[6px] text-slate-500 font-bold mt-1 line-clamp-1">{file.name}</span>
                      </div>
                    ) : (
                      <img src={file.preview} alt="Page" className="w-full h-full object-cover" />
                    )}
                    <button 
                      onClick={() => removeFile(file.id)}
                      className="absolute top-0.5 right-0.5 bg-rose-500 text-white rounded-full p-0.5 shadow-md"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-2.5 w-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {cameraError && <p className="mt-4 text-xs text-rose-500 font-bold text-center">{cameraError}</p>}
          <input 
            ref={fileInputRef}
            type="file" 
            className="hidden" 
            accept="image/*,application/pdf"
            multiple
            onChange={onFileChange} 
          />
        </div>

        <div className="bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-3xl p-5 md:p-6 flex flex-col min-h-[340px] shadow-sm">
          <label className="block text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3">Paste Notes or Material</label>
          <textarea
            className="flex-1 w-full p-4 border border-slate-100 dark:border-slate-700 rounded-2xl resize-none bg-slate-50 dark:bg-slate-900/50 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm text-slate-800 dark:text-slate-200"
            placeholder="Type or paste your study content here..."
            value={textInput}
            onChange={(e) => {
              setTextInput(e.target.value);
              setSelectedFiles([]);
              if (isCameraActive) stopCamera();
            }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
        {/* Difficulty Selection */}
        <div className="flex flex-col items-center gap-3">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Difficulty</span>
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700 w-full">
            {(['Easy', 'Medium', 'Hard'] as Difficulty[]).map((level) => (
              <button
                key={level}
                onClick={() => setDifficulty(level)}
                className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all ${
                  difficulty === level
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300'
                }`}
              >
                {level}
              </button>
            ))}
          </div>
        </div>

        {/* Question Count Selection */}
        <div className="flex flex-col items-center gap-3">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Questions</span>
          <div className="w-full flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
             <input 
              type="number" 
              min="1" 
              max="50"
              value={questionCount}
              onChange={(e) => setQuestionCount(parseInt(e.target.value) || 1)}
              className="w-full bg-transparent text-center font-black text-indigo-600 dark:text-indigo-400 text-sm focus:outline-none"
            />
            <div className="flex flex-col pr-2">
              <button onClick={() => setQuestionCount(q => Math.min(50, q + 1))} className="text-slate-400 hover:text-indigo-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" /></svg>
              </button>
              <button onClick={() => setQuestionCount(q => Math.max(1, q - 1))} className="text-slate-400 hover:text-indigo-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
              </button>
            </div>
          </div>
        </div>

        {/* Time Limit Selection */}
        <div className="flex flex-col items-center gap-3">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Time / Q</span>
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700 w-full">
            {[30, 60, 0].map((limit) => (
              <button
                key={limit}
                onClick={() => setTimeLimit(limit as TimeLimit)}
                className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all ${
                  timeLimit === limit
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300'
                }`}
              >
                {limit === 0 ? 'Unlimited' : `${limit}s`}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-3 pt-4">
        <button
          onClick={() => handleSubmit('quiz')}
          disabled={!canSubmit}
          className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition-all active:scale-[0.98] flex items-center justify-center gap-3 ${
            !canSubmit
              ? 'bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed shadow-none'
              : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200 dark:shadow-indigo-900/20'
          }`}
        >
          {isLoading ? (
             <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          )}
          {isLoading ? "Generating Questions..." : "Generate Mock Test"}
        </button>

        <button
          onClick={() => handleSubmit('expand')}
          disabled={!canSubmit}
          className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition-all active:scale-[0.98] flex items-center justify-center gap-3 ${
            !canSubmit
              ? 'bg-slate-100 dark:bg-slate-800 text-slate-300 dark:text-slate-600 cursor-not-allowed shadow-none border border-slate-200 dark:border-slate-700'
              : 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 shadow-slate-200 dark:shadow-black/20'
          }`}
        >
          {isLoading ? (
             <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          )}
          {isLoading ? "Deep Analyzing..." : "Analyze & Deep Dive"}
        </button>
      </div>
    </div>
  );
};
