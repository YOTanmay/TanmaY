
import React from 'react';

export const AboutView: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-12 py-6">
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-3xl mx-auto flex items-center justify-center text-white shadow-xl rotate-3">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
        </div>
        <h2 className="text-4xl font-black text-slate-800 dark:text-slate-100">About AI Quiz</h2>
        <p className="text-slate-500 dark:text-slate-400 text-lg">
          Revolutionizing the way you study using State-of-the-Art AI.
        </p>
      </div>

      <div className="grid gap-8">
        <section className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm">
          <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center text-sm">01</span>
            Our Mission
          </h3>
          <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
            AI Quiz was built to solve a common problem: turning static learning materials into active practice tools. We believe that active recall and self-testing are the most effective ways to learn, and our goal is to make that process instant and effortless.
          </p>
        </section>

        <section className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm">
          <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-violet-100 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 rounded-lg flex items-center justify-center text-sm">02</span>
            Powered by Gemini
          </h3>
          <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
            The heart of our application is the Google Gemini 3 series models. This advanced AI performs multi-modal analysis—meaning it can "see" your document scans and understand complex educational text just like a human teacher would, but at lightning speed.
          </p>
        </section>

        <section className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm">
          <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg flex items-center justify-center text-sm">03</span>
            Privacy & Performance
          </h3>
          <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
            All your quiz history is stored locally on your device. We don't store your documents on our servers. The app uses the latest web technologies to ensure a smooth, responsive experience whether you're in light or dark mode.
          </p>
        </section>
      </div>

      <div className="text-center pt-8">
        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Version 2.1.0 • Stable</p>
      </div>
    </div>
  );
};
