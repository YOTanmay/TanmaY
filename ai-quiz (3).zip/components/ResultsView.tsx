
import React from 'react';
import { Question, UserAnswer } from '../types';

interface ResultsViewProps {
  questions: Question[];
  answers: UserAnswer[];
  onRestart: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({ questions, answers, onRestart }) => {
  const correctCount = answers.reduce((acc, ans) => {
    const q = questions[ans.questionIndex];
    return acc + (ans.selectedOptionIndex === q?.correctAnswerIndex ? 1 : 0);
  }, 0);

  const scorePercentage = Math.round((correctCount / questions.length) * 100);

  const getScoreMessage = () => {
    if (scorePercentage === 100) return "Mastery Achieved!";
    if (scorePercentage >= 80) return "Excellent Work!";
    if (scorePercentage >= 60) return "Good Progress!";
    return "Needs Review";
  };

  const getScoreColor = () => {
    if (scorePercentage >= 80) return "text-emerald-500 dark:text-emerald-400";
    if (scorePercentage >= 60) return "text-amber-500 dark:text-amber-400";
    return "text-rose-500 dark:text-rose-400";
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Score Overview Card */}
      <div className="bg-white dark:bg-slate-800 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-700 p-8 text-center transition-all">
        <div className="mb-6 inline-block">
          <div className="relative w-32 h-32 md:w-40 md:h-40 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="50%"
                cy="50%"
                r="44%"
                stroke="currentColor"
                strokeWidth="10"
                fill="transparent"
                className="text-slate-100 dark:text-slate-700"
              />
              <circle
                cx="50%"
                cy="50%"
                r="44%"
                stroke="currentColor"
                strokeWidth="10"
                fill="transparent"
                strokeDasharray="277"
                strokeDashoffset={277 - (277 * scorePercentage) / 100}
                strokeLinecap="round"
                className={`${getScoreColor()} transition-all duration-1000 ease-out`}
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-3xl md:text-4xl font-black text-slate-800 dark:text-slate-100">{scorePercentage}%</span>
              <span className="text-[8px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Score</span>
            </div>
          </div>
        </div>
        
        <h2 className={`text-xl md:text-2xl font-black mb-2 ${getScoreColor()}`}>
          {getScoreMessage()}
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-8 font-medium">
          You got <span className="text-slate-900 dark:text-slate-100 font-bold">{correctCount}</span> of <span className="text-slate-900 dark:text-slate-100 font-bold">{questions.length}</span> questions right.
        </p>

        <button
          onClick={onRestart}
          className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4.5 px-12 rounded-2xl transition-all shadow-xl shadow-indigo-200 dark:shadow-indigo-900/20 uppercase tracking-widest text-xs active:scale-95"
        >
          New Session
        </button>
      </div>

      {/* Questions Detailed Review */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-lg font-black text-slate-800 dark:text-slate-100 uppercase tracking-widest">Review Detail</h3>
          <div className="flex gap-4">
             <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
               <div className="w-2 h-2 rounded-full bg-emerald-500" /> Correct
             </div>
             <div className="flex items-center gap-1.5 text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">
               <div className="w-2 h-2 rounded-full bg-rose-500" /> Incorrect
             </div>
          </div>
        </div>

        {questions.map((q, idx) => {
          const userAns = answers.find(a => a.questionIndex === idx);
          const isCorrect = userAns?.selectedOptionIndex === q.correctAnswerIndex;

          return (
            <div 
              key={idx} 
              className={`bg-white dark:bg-slate-800 rounded-[2rem] p-6 md:p-8 shadow-sm border-2 transition-all group ${
                isCorrect 
                  ? 'border-emerald-100 dark:border-emerald-900/20 bg-emerald-50/10 dark:bg-emerald-900/5' 
                  : 'border-rose-100 dark:border-rose-900/20 bg-rose-50/10 dark:bg-rose-900/5'
              }`}
            >
              <div className="flex flex-col md:flex-row items-start gap-6">
                <div className="flex-shrink-0 flex flex-col items-center gap-2">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 ${
                    isCorrect ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
                  }`}>
                    {isCorrect ? (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    )}
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-widest ${isCorrect ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {isCorrect ? "Correct" : "Incorrect"}
                  </span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="mb-6">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Question {idx + 1}</span>
                    <h4 className="font-bold text-slate-800 dark:text-slate-100 text-lg md:text-xl leading-snug">{q.question}</h4>
                  </div>
                  
                  <div className="grid gap-3 mb-6">
                    {q.options.map((opt, oIdx) => {
                      const isUserSelected = userAns?.selectedOptionIndex === oIdx;
                      const isCorrectAnswer = q.correctAnswerIndex === oIdx;

                      let itemStyle = "bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-500 border-slate-100 dark:border-slate-800";
                      
                      if (isCorrectAnswer) {
                        itemStyle = "bg-emerald-50 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 border-emerald-400 dark:border-emerald-600 font-bold shadow-sm shadow-emerald-100 dark:shadow-none";
                      } else if (isUserSelected && !isCorrectAnswer) {
                        itemStyle = "bg-rose-50 dark:bg-rose-900/30 text-rose-800 dark:text-rose-300 border-rose-400 dark:border-rose-600 font-bold shadow-sm shadow-rose-100 dark:shadow-none";
                      }

                      return (
                        <div key={oIdx} className={`p-4 rounded-2xl border-2 flex items-center gap-4 text-sm transition-all duration-300 ${itemStyle}`}>
                          <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-black flex-shrink-0 transition-all ${
                            isCorrectAnswer 
                              ? 'bg-emerald-500 text-white' 
                              : isUserSelected 
                                ? 'bg-rose-500 text-white' 
                                : 'bg-white dark:bg-slate-800 text-slate-400 border border-slate-200 dark:border-slate-700'
                          }`}>
                            {String.fromCharCode(65 + oIdx)}
                          </div>
                          <span className="flex-1 leading-tight">{opt}</span>
                          {isCorrectAnswer && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-emerald-600 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                          )}
                          {isUserSelected && !isCorrectAnswer && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-rose-600 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                            </svg>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Explanation Box */}
                  <div className={`p-5 rounded-2xl border flex gap-4 transition-all ${
                    isCorrect 
                      ? 'bg-emerald-50/30 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900/30' 
                      : 'bg-indigo-50/30 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-900/30'
                  }`}>
                    <div className={`mt-0.5 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      isCorrect ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600' : 'bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600'
                    }`}>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                      </svg>
                    </div>
                    <div>
                      <span className="font-black text-[10px] text-slate-500 dark:text-slate-400 block mb-1 uppercase tracking-[0.15em]">Expert Explanation</span>
                      <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed font-medium italic">
                        {q.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Footer CTA */}
      <div className="flex flex-col items-center gap-4 pt-4">
        <p className="text-sm text-slate-500 font-medium">Ready to try another one?</p>
        <button
          onClick={onRestart}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 px-12 rounded-2xl transition-all shadow-xl shadow-indigo-200 dark:shadow-indigo-900/20 active:scale-95 flex items-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
          </svg>
          New Session
        </button>
      </div>
    </div>
  );
};
