
import React, { useState, useEffect, useRef } from 'react';
import { Question, UserAnswer, TimeLimit } from '../types';

interface QuizViewProps {
  questions: Question[];
  timeLimit: TimeLimit;
  onComplete: (answers: UserAnswer[]) => void;
  onCancel: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({ questions, timeLimit, onComplete, onCancel }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswersMap, setUserAnswersMap] = useState<Record<number, number>>({});
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(timeLimit === 0 ? 0 : timeLimit);
  // Fixed error: Cannot find namespace 'NodeJS'. Using any for timerRef in browser environment.
  const timerRef = useRef<any>(null);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  // Timer logic
  useEffect(() => {
    if (timeLimit === 0) return;

    setTimeLeft(timeLimit);
    if (timerRef.current) clearInterval(timerRef.current);

    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIndex, timeLimit]);

  useEffect(() => {
    const savedAnswer = userAnswersMap[currentIndex];
    setSelectedOption(savedAnswer !== undefined ? savedAnswer : null);
  }, [currentIndex, userAnswersMap]);

  const handleAutoSubmit = () => {
    // If no option is selected, we record it as -1 (wrong) and move on
    const selection = selectedOption !== null ? selectedOption : -1;
    moveToNext(selection);
  };

  const moveToNext = (selection: number) => {
    const newMap = { ...userAnswersMap, [currentIndex]: selection };
    setUserAnswersMap(newMap);

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      finishQuiz(newMap);
    }
  };

  const finishQuiz = (finalMap: Record<number, number>) => {
    const finalAnswers: UserAnswer[] = questions.map((_, idx) => ({
      questionIndex: idx,
      selectedOptionIndex: finalMap[idx] !== undefined ? finalMap[idx] : -1
    }));
    onComplete(finalAnswers);
  };

  const handleNext = () => {
    if (selectedOption === null) return;
    moveToNext(selectedOption);
  };

  const handleBack = () => {
    if (currentIndex > 0) {
      if (selectedOption !== null) {
        setUserAnswersMap(prev => ({ ...prev, [currentIndex]: selectedOption }));
      }
      setCurrentIndex(currentIndex - 1);
    }
  };

  // Timer color logic
  const getTimerColor = () => {
    if (timeLeft > 10) return 'text-indigo-600 dark:text-indigo-400';
    if (timeLeft > 0) return 'text-rose-500 animate-pulse';
    return 'text-slate-400';
  };

  return (
    <div className="max-w-3xl mx-auto -mt-2 animate-in fade-in duration-500">
      <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-2xl overflow-hidden border border-slate-100 dark:border-slate-700 transition-colors">
        
        {/* Progress and Timer Header */}
        <div className="bg-slate-50 dark:bg-slate-900/50 px-5 py-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
          <div className="flex-1 mr-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Question {currentIndex + 1}/{questions.length}</span>
              <div className="flex items-center gap-2">
                {timeLimit > 0 && (
                  <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-black text-xs ${getTimerColor()}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {timeLeft}s
                  </div>
                )}
                <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400">{Math.round(progress)}%</span>
              </div>
            </div>
            <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-500 transition-all duration-300" 
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <button 
            onClick={onCancel}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
            title="Quit Quiz"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 md:p-10 min-h-[420px] flex flex-col">
          <h3 className="text-lg md:text-2xl font-black text-slate-800 dark:text-slate-100 mb-8 leading-tight">
            {currentQuestion.question}
          </h3>

          <div className="grid gap-3 flex-1">
            {currentQuestion.options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedOption(idx)}
                className={`w-full text-left p-4 md:p-6 rounded-2xl border-2 transition-all flex items-center gap-4 group ${
                  selectedOption === idx
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-900 dark:text-indigo-100 ring-4 ring-indigo-50 dark:ring-indigo-900/20'
                    : 'border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 text-slate-600 dark:text-slate-400 hover:border-slate-200 dark:hover:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800/80'
                }`}
              >
                <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center font-black text-xs md:text-sm transition-all flex-shrink-0 ${
                  selectedOption === idx ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-slate-400 dark:text-slate-600 border border-slate-100 dark:border-slate-700 group-hover:scale-110'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </div>
                <span className="text-sm md:text-lg font-bold">{option}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-700 flex gap-3">
          <button
            onClick={handleBack}
            disabled={currentIndex === 0}
            className={`flex-1 py-4.5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all ${
              currentIndex === 0
                ? 'opacity-0 pointer-events-none'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            Back
          </button>

          <button
            onClick={handleNext}
            disabled={selectedOption === null}
            className={`flex-[2] py-4.5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl ${
              selectedOption === null
                ? 'bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200 dark:shadow-indigo-900/20 active:scale-95'
            }`}
          >
            {currentIndex === questions.length - 1 ? 'Finish' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
};
