
import { GoogleGenAI, Type } from "@google/genai";
import { Question, Difficulty, ExpandedTopic } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const QUIZ_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      question: { type: Type.STRING, description: "The quiz question text." },
      options: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: "Exactly 4 multiple choice options." 
      },
      correctAnswerIndex: { type: Type.INTEGER, description: "The 0-based index of the correct option." },
      explanation: { type: Type.STRING, description: "Short explanation of why the answer is correct." }
    },
    required: ["question", "options", "correctAnswerIndex", "explanation"],
    propertyOrdering: ["question", "options", "correctAnswerIndex", "explanation"]
  }
};

const EXPANSION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    summary: { type: Type.STRING },
    keyConcepts: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          term: { type: Type.STRING },
          definition: { type: Type.STRING }
        },
        required: ["term", "definition"]
      }
    },
    detailedExplanation: { type: Type.STRING },
    relatedTopics: { type: Type.ARRAY, items: { type: Type.STRING } },
    furtherReadingSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
    visualPrompt: { type: Type.STRING, description: "A detailed prompt for an AI image generator to create an educational diagram or visual aid for this topic. Be descriptive." }
  },
  required: ["title", "summary", "keyConcepts", "detailedExplanation", "relatedTopics", "furtherReadingSuggestions", "visualPrompt"]
};

export async function generateQuizFromContent(
  text?: string,
  files?: { data: string; mimeType: string }[],
  difficulty: Difficulty = 'Medium',
  targetQuestionCount: number = 10
): Promise<Question[]> {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are an elite educational content extractor and examiner. 
    Your goal is to scan ALL provided materials (text, images, and PDF documents) and convert them into a high-quality mock test.
    
    CRITICAL INSTRUCTIONS:
    1. MULTI-MODAL ANALYSIS: Thoroughly analyze text, images, and PDF files. If a PDF is provided, read all its pages.
    2. EXTRACT EXISTING QUESTIONS: If the document contains questions (test papers, textbook exercises), extract them and convert them into 4-option multiple-choice format.
    3. QUESTION VOLUME: Generate exactly ${targetQuestionCount} questions if possible. If the content is too brief, generate as many high-quality questions as you can, up to ${targetQuestionCount}.
    4. DIFFICULTY SETTING: Strictly follow the "${difficulty}" difficulty level.
    
    Difficulty Guidelines:
    - Easy: Fact recall and simple definitions.
    - Medium: Conceptual understanding and application.
    - Hard: Synthesis, critical analysis, and complex deductions across multiple sources.

    FORMATTING:
    - 4 options per question.
    - Clear explanation for the correct answer.
    - Valid JSON array output.
  `;

  const contents: any = { parts: [] };
  
  if (text) {
    contents.parts.push({ text: `Extract questions from this text content: ${text}` });
  }
  
  if (files && files.length > 0) {
    files.forEach((file, idx) => {
      contents.parts.push({
        inlineData: {
          data: file.data,
          mimeType: file.mimeType
        }
      });
      contents.parts.push({ text: `Attachment ${idx + 1} (${file.mimeType})` });
    });
    contents.parts.push({ text: `Analyze all attachments and generate a quiz with exactly ${targetQuestionCount} questions.` });
  }

  const response = await ai.models.generateContent({
    model,
    contents,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: QUIZ_SCHEMA,
      temperature: 0.3,
    },
  });

  try {
    const responseText = response.text || "[]";
    return JSON.parse(responseText) as Question[];
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Failed to generate quiz. The content might be too complex or the format unsupported.");
  }
}

export async function expandTopicFromContent(
  text?: string,
  files?: { data: string; mimeType: string }[]
): Promise<ExpandedTopic> {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are a professional educational researcher. Synthesize and expand content from all provided sources (text, images, PDFs).
    
    INSTRUCTIONS:
    1. Analyze all inputs for core themes and connections.
    2. Summarize the collective content.
    3. Expand with deep context, applications, and theoretical depth.
    4. Suggest related topics and further reading.
    5. Provide a 'visualPrompt' for a high-quality educational diagram or illustration related to the core topic.

    Output in structured JSON format.
  `;

  const contents: any = { parts: [] };
  
  if (text) {
    contents.parts.push({ text: `Analyze and expand: ${text}` });
  }
  
  if (files && files.length > 0) {
    files.forEach((file, idx) => {
      contents.parts.push({
        inlineData: {
          data: file.data,
          mimeType: file.mimeType
        }
      });
      contents.parts.push({ text: `Attachment ${idx + 1} (${file.mimeType})` });
    });
    contents.parts.push({ text: "Thoroughly analyze all attachments above." });
  }

  const response = await ai.models.generateContent({
    model,
    contents,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: EXPANSION_SCHEMA,
      temperature: 0.7,
    },
  });

  try {
    const responseText = response.text || "{}";
    return JSON.parse(responseText) as ExpandedTopic;
  } catch (error) {
    throw new Error("Failed to expand topic. Please try again.");
  }
}

/**
 * Creates a specialized image prompt for a specific text segment.
 */
export async function generateVisualPromptFromText(segment: string): Promise<string> {
  const model = "gemini-3-flash-preview";
  const response = await ai.models.generateContent({
    model,
    contents: `Create a concise, descriptive Imagen 4.0 prompt for a professional educational diagram or illustration that explains the following concept: "${segment}". Focus on clarity, educational value, and professional style.`,
  });
  return response.text || "Educational diagram";
}

export async function generateVisualAid(prompt: string): Promise<string> {
  try {
    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: `Educational illustration or diagram for students: ${prompt}. Professional, clean, clear labels if applicable, white background where possible, 4k resolution.`,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '1:1',
      },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64EncodeString = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64EncodeString}`;
    }
    return '';
  } catch (error) {
    console.error("Imagen generation failed", error);
    return '';
  }
}

/**
 * AI-assisted link metadata extraction to bypass CORS and provide rich context.
 */
export async function fetchLinkMetadata(url: string): Promise<{ title: string; description: string }> {
  const model = "gemini-3-flash-preview";
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Provide a short title and a 1-sentence description for this educational URL: ${url}. Return as JSON with "title" and "description" keys.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING }
          },
          required: ["title", "description"]
        }
      }
    });
    
    const text = response.text;
    if (text) {
      return JSON.parse(text);
    }
  } catch (e) {
    console.error("Link metadata fetch failed", e);
  }
  return { title: url, description: "Educational resource link" };
}
