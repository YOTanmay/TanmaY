
import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from './components/Layout';
import { FileUploader } from './components/FileUploader';
import { QuizView } from './components/QuizView';
import { ResultsView } from './components/ResultsView';
import { HistoryView } from './components/HistoryView';
import { AboutView } from './components/AboutView';
import { TopicExpansionView } from './components/TopicExpansionView';
import { LoginView } from './components/LoginView';
import { ProfileView } from './components/ProfileView';
import { AppState, Question, UserAnswer, QuizHistoryItem, Difficulty, ExpandedTopic, TimeLimit, User } from './types';
import { generateQuizFromContent, expandTopicFromContent, generateVisualAid, generateVisualPromptFromText } from './services/geminiService';

const HISTORY_KEY = 'ai_quiz_history_v1';
const USER_KEY = 'ai_quiz_user_v1';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(AppState.IDLE);
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(USER_KEY);
    return saved ? JSON.parse(saved) : null;
  });
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<UserAnswer[]>([]);
  const [expandedTopic, setExpandedTopic] = useState<ExpandedTopic | null>(null);
  const [timeLimit, setTimeLimit] = useState<TimeLimit>(0);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<QuizHistoryItem[]>([]);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
        (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });

  useEffect(() => {
    const saved = localStorage.getItem(HISTORY_KEY);
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }, [user]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setState(AppState.IDLE);
  };

  const handleUpdateUser = (updates: Partial<User>) => {
    setUser(prev => prev ? { ...prev, ...updates } : null);
  };

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to log out? Your local study history will remain.")) {
      setUser(null);
      setState(AppState.AUTH);
    }
  };

  const handleProcessContent = async (content: { 
    text?: string; 
    files?: { data: string; mimeType: string }[]; 
    difficulty: Difficulty; 
    mode: 'quiz' | 'expand';
    questionCount: number;
    timeLimit: TimeLimit;
  }) => {
    if (!user) {
      setState(AppState.AUTH);
      return;
    }

    setState(AppState.PROCESSING);
    setError(null);
    setTimeLimit(content.timeLimit);
    
    try {
      if (content.mode === 'quiz') {
        const generatedQuestions = await generateQuizFromContent(
          content.text,
          content.files,
          content.difficulty,
          content.questionCount
        );
        setQuestions(generatedQuestions);
        setState(AppState.QUIZ);
      } else {
        const expansion = await expandTopicFromContent(
          content.text,
          content.files
        );
        
        setExpandedTopic(expansion);
        setState(AppState.TOPIC_EXPANSION);

        if (expansion.visualPrompt) {
          generateVisualAid(expansion.visualPrompt).then(url => {
            if (url) {
              setExpandedTopic(prev => prev ? { ...prev, visualAidUrl: url } : null);
            }
          });
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to process documents. Please check file format or size.");
      setState(AppState.IDLE);
    }
  };

  const handleGenerateSectionVisual = async (index: number, text: string) => {
    if (!expandedTopic) return;
    try {
      const prompt = await generateVisualPromptFromText(text);
      const url = await generateVisualAid(prompt);
      if (url) {
        setExpandedTopic(prev => {
          if (!prev) return null;
          const sectionVisuals = { ...(prev.sectionVisuals || {}), [index]: url };
          return { ...prev, sectionVisuals };
        });
      }
    } catch (err) {
      console.error("Failed to generate section visual", err);
    }
  };

  const handleGenerateQuizFromExpansion = async () => {
    if (!expandedTopic) return;
    setState(AppState.PROCESSING);
    try {
      const generatedQuestions = await generateQuizFromContent(
        expandedTopic.detailedExplanation,
        undefined,
        'Medium',
        10
      );
      setQuestions(generatedQuestions);
      setState(AppState.QUIZ);
    } catch (err: any) {
      setError("Failed to generate quiz from expansion.");
      setState(AppState.TOPIC_EXPANSION);
    }
  };

  const handleQuizComplete = (finalAnswers: UserAnswer[]) => {
    setAnswers(finalAnswers);
    setState(AppState.RESULTS);

    const correctCount = finalAnswers.reduce((acc, ans) => {
      const q = questions[ans.questionIndex];
      return acc + (ans.selectedOptionIndex === q?.correctAnswerIndex ? 1 : 0);
    }, 0);
    const score = Math.round((correctCount / questions.length) * 100);

    const newItem: QuizHistoryItem = {
      id: Date.now().toString(),
      date: Date.now(),
      title: questions[0]?.question.substring(0, 30) + "...", 
      questions: questions,
      answers: finalAnswers,
      score: score
    };

    setHistory(prev => [newItem, ...prev].slice(0, 50)); 
  };

  const handleRestart = () => {
    if (state === AppState.QUIZ && !window.confirm("Abandon quiz? Progress will be lost.")) return;
    setState(AppState.IDLE);
    setQuestions([]);
    setAnswers([]);
    setExpandedTopic(null);
    setError(null);
  };

  const handleNavigate = useCallback((targetState: AppState) => {
    if (state === AppState.QUIZ && !window.confirm("Abandon quiz? Progress will be lost.")) return;
    setState(targetState);
    if (targetState !== AppState.RESULTS) {
       setQuestions([]);
       setAnswers([]);
       setExpandedTopic(null);
    }
    setError(null);
  }, [state]);

  const handleSelectHistoryItem = (item: QuizHistoryItem) => {
    setQuestions(item.questions);
    setAnswers(item.answers);
    setState(AppState.RESULTS);
  };

  return (
    <Layout 
      isDarkMode={isDarkMode} 
      onToggleTheme={toggleTheme} 
      showBack={state !== AppState.IDLE && state !== AppState.HISTORY && state !== AppState.ABOUT && state !== AppState.AUTH && state !== AppState.PROFILE} 
      onBack={handleRestart}
      activeState={state}
      onNavigate={handleNavigate}
      user={user}
      onLogout={handleLogout}
      onUpdateUser={handleUpdateUser}
    >
      {error && (
        <div className="mb-6 bg-rose-50 dark:bg-rose-900/30 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-400 px-4 py-3 rounded-xl flex items-center gap-3 animate-in fade-in duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {state === AppState.AUTH && <LoginView onLogin={handleLogin} />}

      {state === AppState.PROFILE && user && (
        <ProfileView 
          user={user} 
          onUpdate={handleUpdateUser} 
          onLogout={handleLogout} 
          onBack={() => setState(AppState.IDLE)} 
        />
      )}

      {(state === AppState.IDLE) && <FileUploader onProcess={handleProcessContent} isLoading={false} />}

      {state === AppState.PROCESSING && (
        <div className="flex flex-col items-center justify-center py-20 space-y-6">
          <div className="relative">
            <div className="w-24 h-24 border-4 border-slate-100 dark:border-slate-800 border-t-indigo-600 rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600 dark:text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Deep Scanning Documents...</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-2">
              Gemini AI is analyzing all files to generate your custom quiz. This may take up to 30 seconds for large files.
            </p>
          </div>
        </div>
      )}

      {state === AppState.QUIZ && <QuizView questions={questions} timeLimit={timeLimit} onComplete={handleQuizComplete} onCancel={handleRestart} />}
      {state === AppState.RESULTS && <ResultsView questions={questions} answers={answers} onRestart={handleRestart} />}
      {state === AppState.TOPIC_EXPANSION && expandedTopic && <TopicExpansionView data={expandedTopic} onGenerateQuiz={handleGenerateQuizFromExpansion} onBack={handleRestart} onGenerateSectionVisual={handleGenerateSectionVisual} />}
      {state === AppState.HISTORY && <HistoryView history={history} onSelectItem={handleSelectHistoryItem} onDeleteItem={(id) => setHistory(h => h.filter(i => i.id !== id))} onGoHome={() => setState(AppState.IDLE)} />}
      {state === AppState.ABOUT && <AboutView />}
    </Layout>
  );
};

export default App;
