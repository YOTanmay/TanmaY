
export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type TimeLimit = 30 | 60 | 0; // 0 means no limit

export interface User {
  name: string;
  email: string;
  password?: string;
  avatar?: string; // Base64 string of the profile picture
}

export interface Question {
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface UserAnswer {
  questionIndex: number;
  selectedOptionIndex: number;
}

export interface QuizHistoryItem {
  id: string;
  date: number;
  title: string;
  questions: Question[];
  answers: UserAnswer[];
  score: number;
}

export interface ExpandedTopic {
  title: string;
  summary: string;
  keyConcepts: { term: string; definition: string }[];
  detailedExplanation: string;
  relatedTopics: string[];
  furtherReadingSuggestions: string[];
  visualPrompt?: string;
  visualAidUrl?: string;
  sectionVisuals?: Record<number, string>; // Maps paragraph index to generated image URL
}

export enum AppState {
  IDLE = 'IDLE',
  PROCESSING = 'PROCESSING',
  QUIZ = 'QUIZ',
  RESULTS = 'RESULTS',
  HISTORY = 'HISTORY',
  ABOUT = 'ABOUT',
  TOPIC_EXPANSION = 'TOPIC_EXPANSION',
  AUTH = 'AUTH',
  PROFILE = 'PROFILE'
}
